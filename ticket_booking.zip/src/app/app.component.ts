import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  seats: String[][]; // storing seats in array
  
  totalSeatsperRow: number[]; // storing number of seats available in particular row
  
  seatsReq:any; // input
  
  
  mssg: String = ""; // output whether ticket booked or not
  seat: String = ""; // output print seats details for particular user
  totalSeat: any; // total seats available 

  constructor() {
    
        this.seats = [];
        this.totalSeat = 80;
        this.totalSeatsperRow = [];
        for(var i: number = 0; i < 12; i++) {
            this.seats[i] = [];
            if(i == 11){
              this.totalSeatsperRow[i] = 3;
            }else{
              this.totalSeatsperRow[i] = 7;
            }
            for(var j: number = 0; j < 7; j++) {
                this.seats[i][j] = "EMPTY";
            }
        }
       // console.log(this.seats[0][0]);
    }

    // this function is used to generate pnr number
    getRandomNumber(){
      return Math.random() * 10000000000;
    }

    bookTicket(){
      if(this.totalSeat < this.seatsReq){
        this.mssg = "Seats not Available \n seats left: " + this.totalSeat;
      }else{
        let pnr = Math.floor(this.getRandomNumber());
        for(var i: number = 0; i < 12; i++){
          if(this.totalSeatsperRow[i] == 7){
            if(this.seatsReq >= 7){
              this.totalSeatsperRow[i] = 0;
              this.totalSeat -= 7;
              this.seatsReq -= 7;
              for(let index = 0; index < 7; index++){
                this.seats[i][index] = pnr+"";
              }
            }else{
              let temp = this.seatsReq;
              this.totalSeatsperRow[i] -= this.seatsReq;
              this.totalSeat -= temp;
              this.seatsReq -= temp;
              let count = 0;
              for(let index = 0; index < 7 && count < temp; index++){
                if(this.seats[i][index] == "EMPTY"){
                  this.seats[i][index] = pnr+"";
                  count++;
                }
              }
            }

          }else if(this.totalSeatsperRow[i] < 7 && this.seatsReq <= this.totalSeatsperRow[i]){
            let temp = this.seatsReq;
            this.totalSeatsperRow[i] = this.totalSeatsperRow[i]-this.seatsReq;
            this.totalSeat -= temp;
            this.seatsReq -= temp;
            let count = 0;
            for(let index = 0; index < 7 && count < temp; index++){
              if(this.seats[i][index] == "EMPTY"){
                this.seats[i][index] = pnr+"";
                count++;
              }
            }
          }
        }
        if(this.seatsReq == 0){
          this.mssg = "Seats Booked \n your PNR: "+ pnr;
        }else{
          for(var i: number = 0; i < 12; i++){
            if(this.totalSeatsperRow[i] < 7 && this.seatsReq >= this.totalSeatsperRow[i]){
              let temp = this.totalSeatsperRow[i];
              this.totalSeatsperRow[i] = 0;
              this.totalSeat -= temp;
              this.seatsReq -= temp;
              let count = 0;
              for(let index = 0; index < 7 && count < temp; index++){
                if(this.seats[i][index] == "EMPTY"){
                  this.seats[i][index] = pnr+"";
                  count++;
                }
              }
            }
          }
        }
        this.mssg = "Seats Booked \n your PNR: "+ pnr;

        let count = 1; // it will carry seat number
        let seatNum = ""; // final result

        //printing Seats
        for(var i: number = 0; i < 12; i++) {
          for(var j: number = 0; j < 7; j++) {
              if(pnr.toString() == this.seats[i][j] && count <= 80){
                seatNum = seatNum + " " +count;
              }
              count++;
          }
        }
        this.seat = seatNum;

      }
    }

}
